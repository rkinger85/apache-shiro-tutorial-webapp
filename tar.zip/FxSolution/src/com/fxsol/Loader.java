package com.fxsol;

import java.io.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Loader {

    public List<Transaction> getTransactions() {
        List<Transaction> transactions = new ArrayList<>();
        try {
            String line = null;
            BufferedReader reader = new BufferedReader(new FileReader(new File("data/transactions.csv")));
            reader.readLine(); //skip header
            while ((line = reader.readLine()) != null) {
                String[] columns = line.split(",");
                String[] timeCol = columns[4].split(":");
                int timeInMinutes = (Integer.valueOf(timeCol[0]) * 60) + Integer.valueOf(timeCol[1]);
                Transaction transaction = new Transaction(columns[0], columns[1], new BigDecimal(columns[2]),
                        ClientType.valueOf(columns[3].toUpperCase()), timeInMinutes);
                transactions.add(transaction);
            }
        } catch (IOException e) {
            System.out.println("Exception during reading transaction file");
            e.printStackTrace();
        }
        return transactions;
    }

    public List<FxPair> getRates() {
        List<FxPair> rates = new ArrayList<>();
        try {
            String line = null;
            BufferedReader reader = new BufferedReader(new FileReader(new File("data/rates.csv")));
            while ((line = reader.readLine()) != null) {
                String[] columns = line.split(",");
                String[] timeCol = columns[3].split(":");
                int timeInMinutes = (Integer.valueOf(timeCol[0]) * 60) + Integer.valueOf(timeCol[1]);
                FxPair fxPair = new FxPair(columns[0], columns[1], new BigDecimal(columns[2]),timeInMinutes);
                rates.add(fxPair);
            }
        } catch (IOException e) {
            System.out.println("Exception during reading rates file");
            e.printStackTrace();
        }
        return rates;
    }


}
