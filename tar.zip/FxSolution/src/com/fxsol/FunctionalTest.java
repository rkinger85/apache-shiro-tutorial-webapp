package com.fxsol;

import java.util.function.Function;

public class FunctionalTest  {

    public static void main(String[] args) {
        
    }
}
