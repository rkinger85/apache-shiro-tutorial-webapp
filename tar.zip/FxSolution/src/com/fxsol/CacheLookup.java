package com.fxsol;

import java.util.*;

public class CacheLookup {
    private  Map<String, NavigableSet<FxPair>> rateLookupCache;
    private static CacheLookup _instance;
    private Loader loader = new Loader();

    private CacheLookup() {
        List<FxPair> rates = loader.getRates();
        Map<String, NavigableSet<FxPair>> rateMap = new HashMap<>();
        NavigableSet<FxPair> set;
        for (FxPair fxPair : rates) {
            if (rateMap.get(fxPair.getPair()) != null) {
                set = rateMap.get(fxPair.getPair());
            } else {
                set = new TreeSet<>();
            }
            set.add(fxPair);
            rateMap.put(fxPair.getPair(),set);
        }
        rateLookupCache=Collections.unmodifiableMap(rateMap);
    }

    public static synchronized CacheLookup getInstance() {
        if (_instance == null) {
            _instance = new CacheLookup();
        }
        return _instance;
    }

    public  Map<String, NavigableSet<FxPair>> getRateLookupCache() {
        return rateLookupCache;
    }
}
