package com.fxsol;

public class FxPairQuery extends FxPair {

    protected FxPairQuery(Integer transactionTimeInMinutes) {
        super(transactionTimeInMinutes);
    }
}
