package com.fxsol;

import java.math.BigDecimal;

public class Transaction {

    private String baseCurrency;
    private String wantedCurrency;
    private BigDecimal amountInBaseCurrency;
    private ClientType clientType;
    private Integer transactionTimeInMinutes;
    private String transactionPair;
    private BigDecimal amountInUSD;
    private BigDecimal profitInWantedCurrency;
    private BigDecimal profitInSGD;
    private BigDecimal marketRate;
    private BigDecimal finalRate;
    private BigDecimal marketRateSGD;

    public Transaction(String baseCurrency, String wantedCurrency, BigDecimal amountInBaseCurrency,
                       ClientType clientType, Integer transactionTimeInMinutes) {
        this.baseCurrency = baseCurrency;
        this.wantedCurrency = wantedCurrency;
        this.amountInBaseCurrency = amountInBaseCurrency;
        this.clientType = clientType;
        this.transactionTimeInMinutes = transactionTimeInMinutes;
        transactionPair=baseCurrency+"-"+wantedCurrency;
    }

    public String getBaseCurrency() {
        return baseCurrency;
    }

    public String getWantedCurrency() {
        return wantedCurrency;
    }

    public BigDecimal getAmountInBaseCurrency() {
        return amountInBaseCurrency;
    }

    public ClientType getClientType() {
        return clientType;
    }

    public Integer getTransactionTimeInMinutes() {
        return transactionTimeInMinutes;
    }

    public String getTransactionPair() {
        return transactionPair;
    }
    public BigDecimal getAmountInUSD() {
        return amountInUSD;
    }

    public void setAmountInUSD(BigDecimal amountInUSD) {
        this.amountInUSD = amountInUSD;
    }

    public BigDecimal getMarketRate() {
        return marketRate;
    }

    public void setMarketRate(BigDecimal marketRate) {
        this.marketRate = marketRate;
    }

    public BigDecimal getFinalRate() {
        return finalRate;
    }

    public void setFinalRate(BigDecimal finalRate) {
        this.finalRate = finalRate;
    }

    public BigDecimal getProfitInWantedCurrency() {
        return profitInWantedCurrency;
    }

    public void setProfitInWantedCurrency(BigDecimal profitInWantedCurrency) {
        this.profitInWantedCurrency = profitInWantedCurrency;
    }

    public BigDecimal getProfitInSGD() {
        return profitInSGD;
    }

    public void setProfitInSGD(BigDecimal profitInSGD) {
        this.profitInSGD = profitInSGD;
    }

    public BigDecimal getMarketRateSGD() {
        return marketRateSGD;
    }

    public void setMarketRateSGD(BigDecimal marketRateSGD) {
        this.marketRateSGD = marketRateSGD;
    }

    //BaseCurrency,WantedCurrency,AmountInBaseCurrency,StandardRate,FinalRate,ProfitInWantedCurrency,ProfitInSGD

    @Override
    public String toString() {
        return
                baseCurrency + "," +
                wantedCurrency + "," +
                 amountInBaseCurrency+ "," +
                 marketRate + "," +
                 finalRate + "," +
                        profitInWantedCurrency + "," +
                        profitInSGD ;

    }
}
