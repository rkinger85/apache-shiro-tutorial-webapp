package com.fxsol;

import java.math.BigDecimal;

public class FxPair implements Comparable<FxPair> {
private String fromCurrency;
private String toCurrency;
private BigDecimal rate;
private Integer transactionTimeInMinutes;
private String pair;

    public FxPair(String fromCurrency, String toCurrency, BigDecimal rate, Integer transactionTimeInMinutes) {
        this.fromCurrency = fromCurrency;
        this.toCurrency = toCurrency;
        this.rate = rate;
        this.transactionTimeInMinutes = transactionTimeInMinutes;
        this.pair=this.fromCurrency+"-"+this.toCurrency;

    }

    protected FxPair(Integer transactionTimeInMinutes){
        this.transactionTimeInMinutes = transactionTimeInMinutes;
    }


    public String getFromCurrency() {
        return fromCurrency;
    }

    public String getToCurrency() {
        return toCurrency;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public Integer getTransactionTimeInMinutes() {
        return transactionTimeInMinutes;
    }

    public String getPair() {
        return pair;
    }


    @Override
    public int compareTo(FxPair o) {
        return this.transactionTimeInMinutes.compareTo(o.getTransactionTimeInMinutes());
    }

    @Override
    public String toString() {
        return "FxPair{" +
                ", pair='" + pair +
                "transactionTimeInMinutes=" + transactionTimeInMinutes+
                + '\'' +
                '}';
    }
}
