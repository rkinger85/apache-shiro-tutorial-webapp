package com.fxsol;

import java.math.BigDecimal;
import java.util.List;
import java.util.NavigableSet;
import java.util.concurrent.Callable;
import java.util.stream.Collectors;

public class FxProcessor implements Callable<List<Transaction>> {

    List<Transaction> transactionList;
    CacheLookup cacheLookup = CacheLookup.getInstance();
    private static final String USD_CUR = "USD";
    private static final String SGD_CUR = "SGD";

    public FxProcessor(List transactions) {
        transactionList = transactions;
    }

    @Override
    public List<Transaction> call() throws Exception {
        List<Transaction> computedList = transactionList.stream().map(t -> preprocess(t))
                .map(t -> t.getClientType() == ClientType.INDIVIDUAL ? calculateIndividualRate(t) :
                        calculateCorporateRate(t)).map(t -> process(t)).collect(Collectors.toList());
        return computedList;
    }

    private Transaction preprocess(Transaction transaction) {
        //get market rate
        BigDecimal marketRate = getNextCurrencyRate(transaction);
        transaction.setMarketRate(marketRate);

        //get usd rate
        if (!transaction.getBaseCurrency().equalsIgnoreCase(USD_CUR)) {
            BigDecimal marketRateUSD = getNextCurrencyRate(transaction, USD_CUR);
            transaction.setAmountInUSD(transaction.getAmountInBaseCurrency().multiply(marketRateUSD).setScale(2));
        } else {
            transaction.setAmountInUSD(transaction.getAmountInBaseCurrency());
        }
        //get sgd rate
        if (!transaction.getBaseCurrency().equalsIgnoreCase(SGD_CUR)) {
            BigDecimal marketRateSGD = getNextCurrencyRate(transaction, SGD_CUR);
            transaction.setMarketRateSGD(marketRateSGD);
        } else {
            transaction.setMarketRateSGD(transaction.getMarketRate());
        }

        return transaction;
    }

    private Transaction calculateCorporateRate(Transaction transaction) {
        if (transaction.getAmountInUSD().compareTo(new BigDecimal(1000000)) <= 0) {
            transaction.setFinalRate(transaction.getMarketRate().multiply(new BigDecimal(1 - (0.15 / 100))).setScale(4, BigDecimal.ROUND_HALF_EVEN));
        } else if (transaction.getAmountInUSD().compareTo(new BigDecimal(3000000)) <= 0) {
            transaction.setFinalRate(transaction.getMarketRate().multiply(new BigDecimal(1 - (0.10 / 100))).setScale(4, BigDecimal.ROUND_HALF_EVEN));
        } else {
            transaction.setFinalRate(transaction.getMarketRate().multiply(new BigDecimal(1 - (0.05 / 100))).setScale(4, BigDecimal.ROUND_HALF_EVEN));
        }
        return transaction;
    }


    private Transaction calculateIndividualRate(Transaction transaction) {
        if (transaction.getAmountInUSD().compareTo(new BigDecimal(8000)) <= 0) {
            transaction.setFinalRate(transaction.getMarketRate().multiply(new BigDecimal(1 - (0.4 / 100))).setScale(4, BigDecimal.ROUND_HALF_EVEN));
        } else if (transaction.getAmountInUSD().compareTo(new BigDecimal(20000)) <= 0) {
            transaction.setFinalRate(transaction.getMarketRate().multiply(new BigDecimal(1 - (0.35 / 100))).setScale(4, BigDecimal.ROUND_HALF_EVEN));
        } else if (transaction.getAmountInUSD().compareTo(new BigDecimal(35000)) <= 0) {
            transaction.setFinalRate(transaction.getMarketRate().multiply(new BigDecimal(1 - (0.3 / 100))).setScale(4, BigDecimal.ROUND_HALF_EVEN));
        } else {
            transaction.setFinalRate(transaction.getMarketRate().multiply(new BigDecimal(1 - (0.25 / 100))).setScale(4, BigDecimal.ROUND_HALF_EVEN));
        }
        return transaction;
    }

    private BigDecimal getNextCurrencyRate(Transaction transaction) {
        NavigableSet<FxPair> pairSet = cacheLookup.getRateLookupCache().get(transaction.getTransactionPair());
        FxPair pair = pairSet.higher(new FxPairQuery(transaction.getTransactionTimeInMinutes()));
        return pair.getRate();

    }

    private BigDecimal getNextCurrencyRate(Transaction transaction, String wantedCurrency) {
        NavigableSet<FxPair> pairSet = cacheLookup.getRateLookupCache().get(transaction.getBaseCurrency() + "-" + wantedCurrency);
        FxPair pair = pairSet.higher(new FxPairQuery(transaction.getTransactionTimeInMinutes()));
        return pair.getRate();

    }

    private Transaction process(Transaction transaction) {
        transaction.setProfitInWantedCurrency(transaction.getAmountInBaseCurrency().multiply(transaction.getMarketRate()
                .subtract(transaction.getFinalRate())).setScale(2, BigDecimal.ROUND_HALF_EVEN));
        transaction.setProfitInSGD(transaction.getProfitInWantedCurrency()
                .multiply(transaction.getMarketRateSGD()).setScale(2, BigDecimal.ROUND_HALF_EVEN));
        return transaction;
    }

}
