package com.fxsol;

import java.math.BigDecimal;

public class BankTransaction extends Transaction {
    public BankTransaction(String baseCurrency, String wantedCurrency, BigDecimal amountInBaseCurrency, ClientType clientType, Integer transactionTimeInMinutes) {
        super(baseCurrency, wantedCurrency, amountInBaseCurrency, clientType, transactionTimeInMinutes);
    }
}
