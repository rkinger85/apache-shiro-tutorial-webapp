package com.fxsol;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class FxApp {

    public static void main(String[] args) throws IOException, ExecutionException, InterruptedException {
        /*CacheLookup lookup=CacheLookup.getInstance();
        Map<String, NavigableSet<FxPair>> map=lookup.getRateLookupCache();
        NavigableSet<FxPair> set=map.get("SGD-CNY");
        System.out.println(set.higher(new FxPairQuery(659)).getRate())
        ;*/
        int threadCount=5;
        ExecutorService executorService= Executors.newFixedThreadPool(threadCount);
        List<Transaction> transactionList=new Loader().getTransactions();
        int itemsPerThread=transactionList.size()/threadCount;
        System.out.println(transactionList.size()+"-------"+itemsPerThread);
        if(transactionList.size()<threadCount){
            itemsPerThread=threadCount;
        }
        List<Future<Transaction>> futures=new ArrayList<>();

        for(int start=0;start<transactionList.size();start+=itemsPerThread){
            int end=Math.min(start+itemsPerThread,transactionList.size());
            Future result=executorService.submit(new FxProcessor(transactionList.subList(start,end)));
            futures.add(result);
        }

        for(Future result:futures){
            System.out.println(result.get());
        }
        executorService.shutdown();


    }

}
