package com.fxsol;

public enum ClientType {
    INDIVIDUAL,CORPORATE;
}
